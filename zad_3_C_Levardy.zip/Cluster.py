class Cluster:
    def __init__(self, coors: [(int,int)], center_point: (int, int)):
        self.coors = coors
        self.center_point = center_point
